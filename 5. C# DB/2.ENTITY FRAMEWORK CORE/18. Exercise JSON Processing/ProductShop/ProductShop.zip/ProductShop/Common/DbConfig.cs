﻿namespace ProductShop.Common;

public static class DbConfig
{
    public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=ProductShop;Integrated Security=True;Encrypt=False";

}
